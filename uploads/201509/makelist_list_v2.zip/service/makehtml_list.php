<?php

require_once(dirname(__FILE__).'/../include/common.inc.php');
require_once(DEDEINC."/listmakehtml.class.php");
require_once(DEDEINC."/channelunit.class.php");
require_once(DEDEINC."/typelink.class.php");
require_once(DEDEDATA."/cache/inc_catalog_base.inc");
require_once(DEDEINC."/channelunit.func.php");

$makeObj = new Xc_ListMakeHtml();

//是否被锁定
if(Xc_Memory::get('Task-MakeListHtml-lock')){
    exit(json_encode(array('code'=>0, 'message'=>'wait')));
}

//读取待处理栏目数据
$datas   = Xc_Memory::get('Task-MakeListHtml');
if(!$datas){
    exit(json_encode(array('code'=>0, 'message'=>'null')));
}
if(empty($datas['task'])){
    exit(json_encode(array('code'=>0, 'message'=>'end')));
}
$makeObj->setUniqid($datas['uniqid']);

//生成html
$typeinfo = array_pop($datas['task']);
try {
    Xc_Memory::set('Task-MakeListHtml-lock', time(), 3);
    $result = $makeObj->handleTask($typeinfo);
    $datas['usenum'] = intval($datas['usenum'])+$result['num'];
    if(!empty($result['typeinfo'])){
        array_push($datas['task'], $result['typeinfo']);
    }
} catch (Exception $e) {
    if( $e->getCode() != '1123' ){
        $message = $typeinfo['name'].' 模板文件不存在';
        $makeObj->writeLog(array($message));
        exit(json_encode(array('code'=>0, 'message'=>$message)));
    }
}

//更新待处理栏目数据并解锁
Xc_Memory::set('Task-MakeListHtml', $datas);
Xc_Memory::del('Task-MakeListHtml-lock');
exit(json_encode(array('code'=>0, 'message'=>'success', 'data'=>$typeinfo)));