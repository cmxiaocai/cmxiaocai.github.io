<?php
/**
 * 生成列表栏目
 */
require_once(dirname(__FILE__)."/config.php");
require_once(DEDEINC."/typelink.class.php");
require_once(DEDEINC."/listmakehtml.class.php");
require_once(DEDEDATA."/cache/inc_catalog_base.inc");
require_once(DEDEINC."/channelunit.func.php");

$makeObj = new Xc_ListMakeHtml();

//删除正在执行的任务
if($_GET['end_task']){
    Xc_Memory::del('Task-MakeListHtml');
}

//显示操作页面
if(empty($_POST)){
    $datas = Xc_Memory::get('Task-MakeListHtml');
    if(!$datas){
        //任务创建页面
        include DedeInclude('templets/makehtml_list_v2_create.htm');exit;
    }
    if(empty($datas['task'])){
        //任务结束页面
        include DedeInclude('templets/makehtml_list_v2_end.htm');exit;
    }else{
        //任务反馈页面
        include DedeInclude('templets/makehtml_list_v2_handle.htm');exit;
    }
}


$POST    = $_POST;
$action  = $POST['action'];
$makeObj = new Xc_ListMakeHtml();

//创建任务
if($action=='create_task'){
    $tid     = intval($POST['cid']);
    if($POST['datatype']=='add'){
        $tmp = Xc_Memory::get('Task-TypeUpdate');
        $ids = array();
        foreach ($tmp as $key => $value) {
            $ids[$value]=$value;
        }
    }else{
        $TypeObj = new TypeLink($tid);
        $TypeObj->LogicGetIds($tid);
        $TypeObj->LogicIds[$TypeObj->TypeInfos['id']] = $TypeObj->TypeInfos['typename'];
        $ids = $TypeObj->LogicIds;
    }

    $result = $makeObj->createTask($ids);
    Xc_Memory::del('Task-TypeUpdate');
    exit(json_encode($result));
}

//查询任务进度
if($action=='query_task'){
    $result = Xc_Memory::get('Task-MakeListHtml');
    if(empty($result['task'])){
        $result['usenum'] = 1;
        $result['artnum'] = 1;
    }
    if($result){
        unset($result['task']);
    }
    $file   = '../uploads/log/'.$result['uniqid'].'.log';
    $result['logtxt'] = file_get_contents($file);
    exit(json_encode($result));
}

//处理任务
if($action=='handle_task'){
    $datas = Xc_Memory::get('Task-MakeListHtml');
    if(!$datas){
        exit(json_encode(array('code'=>0, 'message'=>'暂无待生成任务')));
    }
    if(empty($datas['task'])){
        exit(json_encode(array('code'=>0, 'message'=>'任务执行完成待确认中')));
    }
    $makeObj->setUniqid($datas['uniqid']);

    //生成html
    $typeinfo = array_pop($datas['task']);
    try {
        $result = $makeObj->handleTask($typeinfo);
        $datas['usenum'] = intval($datas['usenum'])+$result['num'];
        if(!empty($result['typeinfo'])){
            array_push($datas['task'], $result['typeinfo']);
        }
    } catch (Exception $e) {
        if( $e->getCode() != '1123' ){
            $message = $typeinfo['name'].' 模板文件不存在';
            $makeObj->writeLog(array($message));
            exit(json_encode(array('code'=>0, 'message'=>$message)));
        }
    }
    Xc_Memory::set('Task-MakeListHtml', $datas);
    exit(json_encode(array('code'=>0, 'message'=>'生成成功', 'data'=>$typeinfo)));
}