<?php

class Xc_ListMakeHtml{

    private $_isremote = 0;
    private $_unique   = '';

    public function __construct(){
        require_once(DEDEINC."/arc.listview.class.php");
        require_once(DEDEINC."/arc.sglistview.class.php");
    }

    public function setUniqid($unique){
        $this->_unique = $unique;
    }

    public function handleTask($typeinfo){
        set_time_limit(300);
        global $cfg_Cs;

        $tid = $typeinfo['id'];

        //模型ID大于0的时候调用,目前是除了分类和专题
        if($cfg_Cs[$tid][1]>0){
            $lv = new ListView($tid);
        }else{
            $lv = new SgListView($tid);
        }

        if($lv->TypeLink->TypeInfos['ispart']==0 && $lv->TypeLink->TypeInfos['isdefault']!=-1){
            $ntotalpage = $lv->TotalPage;
        }else{
            $ntotalpage = 1;
        }

        $index  = intval($typeinfo['index'])==0 ? 1 : intval($typeinfo['index']);
        $max    = 3;

        $Fields = $lv->TypeLink->TypeInfos;
        $pcfile = $lv->GetMakeFileRule($Fields['id'],'list',$Fields['typedir'],'',$Fields['namerule2']);
        $mfile  = $lv->GetMakeFileRule($Fields['id'],'list',$Fields['typedir'],'',$Fields['namerule_multi_list']);

        $result = array();
        if( $typeinfo['max']!=='N' && ( intval($typeinfo['index']) >= intval($typeinfo['max']) ) ){
            return array();
        }

        //生成PC页面
        $lv->MakeHtml($index, $max, $this->_isremote);
        for ($i=1; $i <= $max ; $i++) { 
            $result[] = str_replace('{page}', ($i+$index)-1, $pcfile);
        }

        $typeinfo['total'] = $lv->TotalResult;
        $typeinfo['max']   = $lv->TotalPage;
        $typeinfo['index'] = intval($typeinfo['index']) + $max;

        //生成手机页面
        $template_count = count(explode(',', $lv->TypeLink->TypeInfos['tempindex_multi']));
        for($i=0; $i<$template_count; $i++) {
            $lv->MakeHtml($index, $max, $this->_isremote, $i);
            for ($i=1; $i <= $max ; $i++) { 
                $result[] = str_replace('{page}', ($i+$index)-1, str_replace('hiapk', 'hiweb', $mfile));
            }
        }

        $this->writeLog($result);
        return array(
            'num'      => $max*$lv->PageSize,
            'typeinfo' => $typeinfo
        );
    }

    public function createTask($types){
        set_time_limit(300);
        global $dsql;
        $rows = array();
        foreach ($types as $typeid => $name) {
            $rows[$typeid] = array(
                'id'    => $typeid,
                'name'  => $name,
                'total' => 'N',
                'max'   => 'N',
                'index' => 1
            );
        }

        $ids = implode(',', array_filter(array_keys($types)));
        $row = $dsql->GetOne("SELECT count(id) as count FROM dede_archives WHERE typeid IN({$ids})");

        $result = array(
            'uniqid'    => date('Ymd').'-'.md5(time()),
            'artnum'    => $row['count'],
            'usenum'    => 0,
            'count'     => count($rows),
            'pagecount' => 0,
            'task'      => $rows,
        );
        Xc_Memory::set('Task-MakeListHtml', $result);
        return $result;
    }

    public function writeLog($content){
        $dir  = '../uploads/log/';
        $time = date('Ymd H:i:s');
        if( !file_exists($dir) ){
            mkdir($dir);
        }
        $file = $dir.$this->_unique.'.log';
        foreach ($content as $value) {
            file_put_contents($file, '['.$time.']'.$value."\r\n", FILE_APPEND);
        }
    }
}

class Xc_Memory{
    static public function connect(){
        global $cfg_memcache_mc_defa;
        preg_match('/memcache:\/\/(.*):(.*)\//', $cfg_memcache_mc_defa, $matches);
        $ip   = $matches[1];
        $prot = $matches[2];
        $memcache = new Memcache;
        $memcache->connect($ip, $prot);
        return $memcache;
    }
    static public function set($key, $value, $time=86400){
        $memcache = self::connect();
        $memcache->set($key, $value, 0, $time);
    }
    static public function get($key){
        $memcache = self::connect();
        return $memcache->get($key);
    }
    static public function del($key){
        $memcache = self::connect();
        $memcache->delete($key);
    }
}
